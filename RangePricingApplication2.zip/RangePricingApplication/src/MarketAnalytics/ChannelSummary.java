/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MarketAnalytics;

import TheBusiness.MarketModel.Channel;

/**
 *
 * @author kal bugrara
 */
public class ChannelSummary {
    
    Channel channel;
    
    public ChannelSummary(Channel m){
       channel=m;
       
    }
       
    
}
