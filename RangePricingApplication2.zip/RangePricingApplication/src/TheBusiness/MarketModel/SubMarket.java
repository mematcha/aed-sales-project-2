/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TheBusiness.MarketModel;

/**
 *
 * @author asus
 */
public class SubMarket {
   
/**
 * Represents a submarket, which is a specialized type of market.
 */
public class Submarket extends Market {

    public Submarket(String name) {
        super(name);
    }

    // Additional features or behavior specific to Submarket can be added here
}

}
